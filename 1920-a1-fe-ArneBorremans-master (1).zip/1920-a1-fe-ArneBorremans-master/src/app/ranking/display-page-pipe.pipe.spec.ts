import { DisplayPagePipePipe } from './display-page-pipe.pipe';

describe('DisplayPagePipePipe', () => {
  it('create an instance', () => {
    const pipe = new DisplayPagePipePipe();
    expect(pipe).toBeTruthy();
  });
});
