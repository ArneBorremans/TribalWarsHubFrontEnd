import { NameFilterPipe } from './name-filter.pipe';

describe('NameFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new NameFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
