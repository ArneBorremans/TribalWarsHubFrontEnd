import { PointpipePipe } from './pointpipe.pipe';

describe('PointpipePipe', () => {
  it('create an instance', () => {
    const pipe = new PointpipePipe();
    expect(pipe).toBeTruthy();
  });
});
