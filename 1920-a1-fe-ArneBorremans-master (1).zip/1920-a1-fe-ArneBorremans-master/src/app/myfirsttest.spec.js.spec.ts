import { Myfirsttest.Spec.Js } from './myfirsttest.spec.js';

describe('Myfirsttest.Spec.Js', () => {
  it('should create an instance', () => {
    expect(new Myfirsttest.Spec.Js()).toBeTruthy();
  });
});
