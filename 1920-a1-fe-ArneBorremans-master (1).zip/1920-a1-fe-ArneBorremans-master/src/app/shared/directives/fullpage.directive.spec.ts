import { FullpageDirective } from './fullpage.directive';

describe('FullpageDirective', () => {
  it('should create an instance', () => {
    const directive = new FullpageDirective();
    expect(directive).toBeTruthy();
  });
});
