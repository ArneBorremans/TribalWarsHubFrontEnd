export class Myfirsttest.Spec.Js {
}
